
import db from '../config/database.js';
import bcrypt from 'bcrypt';

export async function register(req, res) {
    try {
        const { full_name, email, phone, password } = req.body;

        // Kiem tra du lieu dau vao
        if (!full_name || !email || !phone || !password) {
            return res.status(400).send('Vui long nhap day du thong tin!');
        }

        if (password.length < 8) {
            return res.status(400).send('Mat khau phai co it nhat 8 ky tu!');
        }

        const normalizedEmail = email.trim().toLowerCase();

        // Kiem tra email da ton tai
        const existingUser = await db('users')
            .where({ email: normalizedEmail })
            .first();

        if (existingUser) {
            return res.status(400).send('Email da duoc dang ky!');
        }

        // Ma hoa mat khau
        const passwordHash = await bcrypt.hash(password, 10);

        // Tao tai khoan va gan quyen trong mot transaction
        await db.transaction(async (trx) => {
            const [user] = await trx('users')
                .insert({
                    full_name: full_name.trim(),
                    email: normalizedEmail,
                    phone: phone.trim(),
                    password_hash: passwordHash,
                    is_verified: false,
                    is_active: true
                })
                .returning('id');

            const customerRole = await trx('roles')
                .where({ name: 'customer' })
                .first();

            if (!customerRole) {
                throw new Error('Khong tim thay quyen customer!');
            }

            await trx('user_roles').insert({
                user_id: user.id,
                role_id: customerRole.id
            });
        });

        res.send('Dang ky tai khoan thanh cong!');

    } catch (error) {
        console.error('Loi dang ky:', error.message);
        res.status(500).send('Dang ky that bai. Vui long thu lai!');
    }
}
